# ⚡ Ultra-Fast Dev Agent

Local, fully-offline coding assistant with hot-swappable modes — optimized for **RTX 3080 10GB**.

---

## Architecture

```
ultrafast-dev-agent/
├── config/
│   └── modes.json           ← All mode configs, VRAM budgets, ollama params
├── core/
│   ├── vram_calculator.py   ← VRAM estimation & overflow prevention
│   ├── model_manager.py     ← Model lifecycle, hot-switching, streaming
│   ├── auto_router.py       ← Intelligent task → mode classification
│   ├── agent.py             ← Main orchestrator (routing + inference + retries)
│   └── server.py            ← FastAPI HTTP/SSE server
├── ui/
│   └── index.html           ← Mode toggle UI + streaming chat
├── installer/
│   └── install.bat          ← Zero-touch Windows installer
├── scripts/
│   └── validate.py          ← Full system validation suite
├── logs/                    ← Server + switch history logs
├── models/                  ← Model storage (managed by Ollama)
└── requirements.txt
```

---

## Modes

| Mode | Model | VRAM | Context | Max Tokens | Retries | Target Latency |
|------|-------|------|---------|------------|---------|----------------|
| ⚡ **Dev Mode** | qwen2.5-coder:7b Q4_K_M | ~5.2 GB | 4096 | 1024 | 1 | **1–3 sec** |
| ⚖️ **Balanced** | qwen2.5-coder:14b Q4_K_M | ~9.2 GB | 8192 | 2048 | 3 | 5–10 sec |
| 🔍 **Deep Debug** | qwen2.5-coder:14b Q4_K_M | ~9.5 GB | 12288 | 4096 | 5 | 10–20 sec |
| 🤖 **Full Agent** | qwen2.5-coder:32b Q4_K_M | ~19 GB* | 16384 | 8192 | 10 | 30–60 sec |

*32B requires CPU RAM overflow (~9 GB RAM spill). 14B used as fallback if 32B not downloaded.

---

## VRAM Budget (RTX 3080 10GB)

```
Available VRAM:  9,840 MB  (10,240 MB total − 400 MB CUDA overhead)

Dev Mode (7B):   weights=4,275 MB  + KV=512 MB  + overhead=400 MB = 5,187 MB  ✅ Fits
Balanced (14B):  weights=8,325 MB  + KV=768 MB  + overhead=400 MB = 9,493 MB  ✅ Fits (tight)
Deep Debug(14B): weights=8,325 MB  + KV=1024 MB + overhead=400 MB = 9,749 MB  ✅ Fits (very tight)
Full Agent(32B): weights=18,281 MB [CPU overflow to RAM]            VRAM=partial ⚠️
```

---

## Installation (Windows)

```bat
cd ultrafast-dev-agent
installer\install.bat
```

Installer will:
1. Detect RTX 3080 GPU
2. Install Python dependencies
3. Download & install Ollama
4. Pull `qwen2.5-coder:7b` (Dev model, ~4.7 GB)
5. Pull `qwen2.5-coder:14b` (Balanced/Debug model, ~9 GB)
6. Optionally pull `qwen2.5-coder:32b` (Full Agent, ~19 GB)
7. Set CUDA environment variables
8. Run VRAM validation
9. Create `launch_all.bat`

---

## Running

```bat
launch_all.bat          # Start server (Ollama + FastAPI)
ui\index.html           # Open in browser
```

Or manually:
```bat
ollama serve            # Terminal 1
python core\server.py   # Terminal 2
```

---

## API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Ollama status + active model |
| `/status` | GET | VRAM, mode, model info |
| `/modes` | GET | List all available modes |
| `/mode/switch` | POST | Hot-switch mode (no restart) |
| `/complete` | POST | Non-streaming completion |
| `/stream` | POST | SSE streaming completion |
| `/router/toggle` | POST | Enable/disable auto-router |
| `/session/new` | POST | Start new session |

### Example: Stream a completion

```bash
curl -X POST http://127.0.0.1:8765/stream \
  -H "Content-Type: application/json" \
  -d '{"prompt": "write a binary search function in Python", "use_router": true}'
```

### Example: Switch to Deep Debug

```bash
curl -X POST http://127.0.0.1:8765/mode/switch \
  -H "Content-Type: application/json" \
  -d '{"mode": "deep_debug"}'
```

---

## Auto-Router Logic

The router classifies task complexity (0–10 score) and maps to modes:

| Score | Mode | Examples |
|-------|------|---------|
| 0–1 | ⚡ Dev Mode | Fix typo, add docstring, rename variable |
| 2–4 | ⚖️ Balanced | Write class, unit tests, code review |
| 5–7 | 🔍 Deep Debug | Crash analysis, logic bugs, memory leaks |
| 8–10 | 🤖 Full Agent | Full project, architecture, multi-file refactor |

**Escalation:** 2 consecutive failures → auto-escalate to next mode.  
**Fallback:** After Full Agent / Deep Debug task → return to Dev Mode.

---

## Validation

```bash
python scripts\validate.py
```

Checks:
- All required files present
- Config JSON valid & complete
- VRAM budget calculated for all modes
- Python dependencies installed
- Ollama reachable
- Models downloaded
- Port 8765 available
- Auto-router classifications correct
- Mode-switch enum logic valid

---

## Performance Tuning (RTX 3080)

Key Ollama parameters set by Dev Mode:

```json
{
  "num_gpu":   99,      // All layers to GPU
  "num_ctx":   4096,    // Reduced context for speed
  "num_batch": 512,     // Optimized batch for 3080
  "num_thread": 6,      // Ryzen 5 5600X (6 cores)
  "f16_kv":    true,    // Half-precision KV cache (halves KV VRAM)
  "use_mmap":  true,    // Memory-mapped model loading
  "use_mlock": false,   // Don't lock (allows OS to manage)
  "temperature": 0.1,   // Low temp = deterministic code
  "max_tokens": 1024    // Cap generation for latency
}
```

---

## No External Dependencies

- Fully offline after installation
- No OpenAI / Anthropic API
- No cloud calls
- All models stored locally
- Ollama manages GPU memory

---

*Built for Windows 10 x64 · Ryzen 5 5600X · 32GB RAM · RTX 3080 10GB*
