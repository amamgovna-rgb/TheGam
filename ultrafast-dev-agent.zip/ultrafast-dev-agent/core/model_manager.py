"""
model_manager.py
Handles dynamic model switching between Dev / Balanced / Deep Debug / Full Agent modes.
No application restart required.  Validates VRAM before every switch.
"""

import json
import time
import logging
import asyncio
import aiohttp
import pathlib
from datetime import datetime
from typing import Optional, Callable
from enum import Enum

from vram_calculator import calculate_vram, validate_mode_config

logger = logging.getLogger("model_manager")

# ── Paths ─────────────────────────────────────────────────────────────────
ROOT_DIR   = pathlib.Path(__file__).parent.parent
CONFIG_DIR = ROOT_DIR / "config"
MODES_FILE = CONFIG_DIR / "modes.json"
LOG_DIR    = ROOT_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)


class AgentMode(str, Enum):
    ULTRA_FAST_DEV = "ultra_fast_dev"
    BALANCED       = "balanced"
    DEEP_DEBUG     = "deep_debug"
    FULL_AGENT     = "full_agent"


class SwitchResult(str, Enum):
    SUCCESS        = "success"
    VRAM_OVERFLOW  = "vram_overflow"
    MODEL_MISSING  = "model_missing"
    OLLAMA_ERROR   = "ollama_error"
    ALREADY_ACTIVE = "already_active"


class ModelManager:
    """
    Manages model lifecycle and mode switching.
    Thread-safe, async-first.
    """

    def __init__(self):
        self._config:       dict                   = {}
        self._active_mode:  AgentMode              = AgentMode.ULTRA_FAST_DEV
        self._active_model: str                    = ""
        self._switching:    bool                   = False
        self._callbacks:    list[Callable]         = []
        self._ollama_url:   str                    = ""
        self._vram_mb:      float                  = 9840
        self._load()

    # ── Config Loading ─────────────────────────────────────────────────────

    def _load(self) -> None:
        if not MODES_FILE.exists():
            raise FileNotFoundError(f"modes.json not found at {MODES_FILE}")
        self._config    = json.loads(MODES_FILE.read_text())
        hw              = self._config.get("hardware_profile", {})
        self._vram_mb   = hw.get("vram_available_mb", 9840)
        oll             = self._config.get("ollama", {})
        self._ollama_url = f"http://{oll.get('host','127.0.0.1')}:{oll.get('port',11434)}"
        saved_mode = self._config.get("active_mode", "ultra_fast_dev")
        try:
            self._active_mode = AgentMode(saved_mode)
        except ValueError:
            logger.warning(f"Invalid active_mode '{saved_mode}' in modes.json, defaulting to ultra_fast_dev")
            self._active_mode = AgentMode.ULTRA_FAST_DEV
        try:
            self._active_model = self._config["modes"][self._active_mode.value]["model"]["primary"]
        except KeyError:
            logger.warning("Could not read primary model from modes.json, using fallback")
            self._active_model = "qwen2.5-coder:7b-q4_K_M"
        logger.info(f"ModelManager loaded. Active: {self._active_mode} / {self._active_model}")

    def _save_active(self) -> None:
        self._config["active_mode"]    = self._active_mode.value
        self._config["last_switched"]  = datetime.utcnow().isoformat()
        MODES_FILE.write_text(json.dumps(self._config, indent=2))

    # ── Public API ─────────────────────────────────────────────────────────

    @property
    def active_mode(self) -> AgentMode:
        return self._active_mode

    @property
    def active_model(self) -> str:
        return self._active_model

    @property
    def active_config(self) -> dict:
        return self._config["modes"][self._active_mode.value]

    def register_callback(self, fn: Callable) -> None:
        """Register a function to be called after every mode switch."""
        self._callbacks.append(fn)

    async def switch_mode(
        self,
        target_mode: AgentMode,
        force:       bool = False,
    ) -> tuple[SwitchResult, str]:
        """
        Hot-switch to target mode.
        Returns (SwitchResult, message).
        """
        if self._switching and not force:
            return SwitchResult.OLLAMA_ERROR, "Switch already in progress."

        if target_mode == self._active_mode and not force:
            return SwitchResult.ALREADY_ACTIVE, f"Already in {target_mode.value}"

        self._switching = True
        t0 = time.perf_counter()

        try:
            mode_cfg   = self._config["modes"][target_mode.value]
            new_model  = mode_cfg["model"]["primary"]

            # ── 1. VRAM validation ────────────────────────────────────────
            vram_result = validate_mode_config(mode_cfg, self._vram_mb)
            if not vram_result["valid"]:
                msg = f"VRAM overflow: {vram_result['issues'][0]}"
                logger.error(msg)
                return SwitchResult.VRAM_OVERFLOW, msg

            # Apply safe gpu_layers
            safe_layers = vram_result["safe_gpu_layers"]
            mode_cfg["ollama_params"]["num_gpu"] = safe_layers

            # ── 2. Model availability check ───────────────────────────────
            available = await self._list_local_models()
            base_name = new_model.split(":")[0]
            # Find the actual installed model name that matches (exact first, then base name)
            matched_model = None
            if new_model in available:
                matched_model = new_model          # exact tag match
            else:
                for m in available:
                    if m.startswith(base_name):
                        matched_model = m          # use whatever tag is actually installed
                        break

            if not matched_model:
                # Try fallback
                fallback = mode_cfg["model"].get("fallback", "")
                fb_base  = fallback.split(":")[0] if fallback else ""
                fallback_matched = None
                if fallback:
                    if fallback in available:
                        fallback_matched = fallback
                    else:
                        for m in available:
                            if m.startswith(fb_base):
                                fallback_matched = m
                                break
                if fallback_matched:
                    logger.warning(f"Primary {new_model} not found; using fallback {fallback_matched}")
                    new_model = fallback_matched
                else:
                    return (
                        SwitchResult.MODEL_MISSING,
                        f"Model '{new_model}' not found. Run installer to download it."
                    )
            else:
                if matched_model != new_model:
                    logger.info(f"Resolved '{new_model}' -> '{matched_model}' (installed tag)")
                new_model = matched_model

            # ── 3. Unload current model (free VRAM) ───────────────────────
            await self._unload_model(self._active_model)
            await asyncio.sleep(0.3)   # small pause for VRAM to settle

            # ── 4. Warm-load new model ────────────────────────────────────
            ok = await self._preload_model(new_model, mode_cfg)
            if not ok:
                # Reload previous model as safety net
                prev_cfg = self._config["modes"][self._active_mode.value]
                await self._preload_model(self._active_model, prev_cfg)
                return SwitchResult.OLLAMA_ERROR, "Failed to load new model; reverted."

            # ── 5. Commit switch ──────────────────────────────────────────
            prev_mode        = self._active_mode
            self._active_mode  = target_mode
            self._active_model = new_model
            self._save_active()

            elapsed = (time.perf_counter() - t0) * 1000
            msg = (
                f"Switched {prev_mode.value} → {target_mode.value} "
                f"({new_model}) in {elapsed:.0f}ms"
            )
            logger.info(msg)

            for cb in self._callbacks:
                try:
                    asyncio.create_task(cb(target_mode, new_model))
                except Exception as e:
                    logger.warning(f"Callback error: {e}")

            # Log to switch history
            self._log_switch(prev_mode, target_mode, new_model, elapsed)
            return SwitchResult.SUCCESS, msg

        except Exception as e:
            logger.exception(f"switch_mode error: {e}")
            return SwitchResult.OLLAMA_ERROR, str(e)
        finally:
            self._switching = False

    # ── Ollama Integration ─────────────────────────────────────────────────

    async def _list_local_models(self) -> list[str]:
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"{self._ollama_url}/api/tags", timeout=aiohttp.ClientTimeout(total=5)) as r:
                    if r.status == 200:
                        data = await r.json()
                        return [m["name"] for m in data.get("models", [])]
        except Exception as e:
            logger.warning(f"_list_local_models: {e}")
        return []

    async def _unload_model(self, model_name: str) -> bool:
        """
        Force Ollama to unload a model from VRAM by setting keep_alive=0.
        """
        if not model_name:
            return True
        try:
            payload = {
                "model":      model_name,
                "keep_alive": 0,
                "prompt":     "",
            }
            async with aiohttp.ClientSession() as s:
                async with s.post(
                    f"{self._ollama_url}/api/generate",
                    json    = payload,
                    timeout = aiohttp.ClientTimeout(total=10),
                ) as r:
                    return r.status == 200
        except Exception as e:
            logger.warning(f"_unload_model {model_name}: {e}")
            return False

    async def _preload_model(self, model_name: str, mode_cfg: dict) -> bool:
        """
        Pre-warm model into VRAM with a minimal prompt.
        Applies ollama_params as model options.
        """
        params = mode_cfg.get("ollama_params", {})
        gen_p  = mode_cfg.get("generation_params", {})

        payload = {
            "model":      model_name,
            "prompt":     "",          # empty = just load weights
            "keep_alive": "10m",
            "options": {
                "num_gpu":     params.get("num_gpu",   99),
                "num_ctx":     params.get("num_ctx",   4096),
                "num_batch":   params.get("num_batch", 512),
                "num_thread":  params.get("num_thread", 6),
                "f16_kv":      params.get("f16_kv",    True),
                "use_mmap":    params.get("use_mmap",  True),
                "use_mlock":   params.get("use_mlock", False),
                "low_vram":    params.get("low_vram",  False),
                "temperature": gen_p.get("temperature", 0.1),
                "top_p":       gen_p.get("top_p",       0.9),
                "top_k":       gen_p.get("top_k",       20),
            },
        }

        try:
            async with aiohttp.ClientSession() as s:
                async with s.post(
                    f"{self._ollama_url}/api/generate",
                    json    = payload,
                    timeout = aiohttp.ClientTimeout(total=60),
                ) as r:
                    if r.status == 200:
                        logger.info(f"Pre-loaded {model_name}")
                        return True
                    err = await r.text()
                    logger.error(f"Pre-load {model_name} failed [{r.status}]: {err}")
                    return False
        except Exception as e:
            logger.error(f"_preload_model {model_name}: {e}")
            return False

    # ── Streaming Inference ────────────────────────────────────────────────

    async def stream_completion(
        self,
        prompt:     str,
        system:     str  = "",
        on_chunk:   Optional[Callable[[str], None]] = None,
    ) -> str:
        """
        Stream a completion from the active model.
        Calls on_chunk(text) for each streamed token chunk.
        Returns full response string.
        """
        mode_cfg = self.active_config
        params   = mode_cfg["ollama_params"]
        gen_p    = mode_cfg["generation_params"]

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        payload = {
            "model":  self._active_model,
            "messages": messages,
            "stream":   True,
            "options": {
                "num_gpu":        params.get("num_gpu",     99),
                "num_ctx":        params.get("num_ctx",     4096),
                "num_batch":      params.get("num_batch",   512),
                "num_thread":     params.get("num_thread",  6),
                "temperature":    gen_p.get("temperature",  0.1),
                "top_p":          gen_p.get("top_p",        0.9),
                "top_k":          gen_p.get("top_k",        20),
                "repeat_penalty": gen_p.get("repeat_penalty", 1.05),
                "num_predict":    gen_p.get("max_tokens",  1024),
                "stop":           gen_p.get("stop",        []),
            },
        }

        full_text  = []
        t_start    = time.perf_counter()
        first_token = True

        try:
            timeout = aiohttp.ClientTimeout(total=120, connect=5)
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self._ollama_url}/api/chat",
                    json    = payload,
                    timeout = timeout,
                ) as resp:
                    if resp.status != 200:
                        err = await resp.text()
                        raise RuntimeError(f"Ollama error {resp.status}: {err}")

                    async for raw_line in resp.content:
                        line = raw_line.decode("utf-8").strip()
                        if not line:
                            continue
                        try:
                            chunk = json.loads(line)
                        except json.JSONDecodeError:
                            continue

                        token = chunk.get("message", {}).get("content", "")
                        if token:
                            if first_token:
                                ttft = (time.perf_counter() - t_start) * 1000
                                logger.debug(f"TTFT: {ttft:.1f}ms")
                                first_token = False
                            full_text.append(token)
                            if on_chunk:
                                on_chunk(token)

                        if chunk.get("done", False):
                            break

        except asyncio.CancelledError:
            logger.info("Streaming cancelled by client.")
        except Exception as e:
            logger.error(f"stream_completion error: {e}")
            raise

        elapsed = (time.perf_counter() - t_start) * 1000
        logger.debug(f"Total inference: {elapsed:.1f}ms, tokens: {len(full_text)}")
        return "".join(full_text)

    # ── Switch History ─────────────────────────────────────────────────────

    def _log_switch(
        self,
        from_mode: AgentMode,
        to_mode:   AgentMode,
        model:     str,
        elapsed_ms: float,
    ) -> None:
        log_file = LOG_DIR / "mode_switches.jsonl"
        entry = {
            "ts":        datetime.utcnow().isoformat(),
            "from":      from_mode.value,
            "to":        to_mode.value,
            "model":     model,
            "elapsed_ms": round(elapsed_ms, 1),
        }
        with log_file.open("a") as f:
            f.write(json.dumps(entry) + "\n")

    # ── Status ─────────────────────────────────────────────────────────────

    def status(self) -> dict:
        mode_cfg = self.active_config
        est      = calculate_vram(
            self._active_model,
            mode_cfg["ollama_params"].get("num_ctx", 4096),
            mode_cfg["ollama_params"].get("num_batch", 512),
            mode_cfg["ollama_params"].get("f16_kv", True),
            self._vram_mb,
        )
        return {
            "active_mode":       self._active_mode.value,
            "active_model":      self._active_model,
            "vram_used_mb":      est.total_required_mb,
            "vram_available_mb": self._vram_mb,
            "vram_headroom_mb":  round(self._vram_mb - est.total_required_mb, 1),
            "fits_on_gpu":       est.fits_on_gpu,
            "gpu_layers":        est.gpu_layers,
            "switching":         self._switching,
        }
