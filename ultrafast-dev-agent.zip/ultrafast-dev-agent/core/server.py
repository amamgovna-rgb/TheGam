"""
server.py
FastAPI server exposing the Ultra-Fast Dev Agent over HTTP with SSE streaming.
Includes mode-switching endpoints and health check.
"""

import asyncio
import json
import logging
import sys
import pathlib
from contextlib import asynccontextmanager
from typing import Optional, AsyncGenerator

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

# Ensure core directory is on path
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent / "core"))

from agent import Agent
from model_manager import AgentMode

logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(
            pathlib.Path(__file__).parent.parent / "logs" / "server.log"
        ),
    ],
)
logger = logging.getLogger("server")

# ── Lifespan ───────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Ultra-Fast Dev Agent server starting…")
    health = await agent.health_check()
    if not health.get("ollama_reachable"):
        logger.warning("⚠️  Ollama not reachable at startup. Start Ollama service.")
    else:
        logger.info(
            f"✅ Ollama OK — {health['models_loaded']} model(s) available. "
            f"Active: {health['active_model']}"
        )
    yield
    # Shutdown
    logger.info("Server shutting down.")


# ── App Init ──────────────────────────────────────────────────────────────

app   = FastAPI(title="Ultra-Fast Dev Agent", version="1.0.0", lifespan=lifespan)
agent = Agent()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request Models ─────────────────────────────────────────────────────────

class CompletionRequest(BaseModel):
    prompt:        str
    session_id:    str            = "default"
    code_context:  str            = ""
    file_count:    int            = 1
    error_message: str            = ""
    use_router:    bool           = True
    stream:        bool           = True


class ModeRequest(BaseModel):
    mode:       str
    session_id: Optional[str] = None


class RouterToggle(BaseModel):
    enabled: bool


# ── Endpoints ──────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return await agent.health_check()


@app.get("/status")
async def status():
    return agent.status()


@app.get("/modes")
async def list_modes():
    cfg_path = pathlib.Path(__file__).parent.parent / "config" / "modes.json"
    cfg      = json.loads(cfg_path.read_text())
    modes    = {
        k: {
            "display_name": v["display_name"],
            "description":  v["description"],
            "model":        v["model"]["primary"],
        }
        for k, v in cfg["modes"].items()
    }
    return {
        "modes":       modes,
        "active_mode": agent.model_mgr.active_mode.value,
    }


@app.post("/mode/switch")
async def switch_mode(req: ModeRequest):
    ok, msg = await agent.set_mode(req.mode, req.session_id)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"success": True, "message": msg, "active_mode": req.mode}


@app.post("/router/toggle")
async def toggle_router(req: RouterToggle):
    agent.router.toggle(req.enabled)
    return {"auto_router": req.enabled}


@app.post("/complete")
async def complete(req: CompletionRequest):
    """
    Non-streaming completion endpoint.
    """
    response = await agent.ask(
        prompt        = req.prompt,
        session_id    = req.session_id,
        code_context  = req.code_context,
        file_count    = req.file_count,
        error_message = req.error_message,
        use_router    = req.use_router,
    )
    return {
        "text":       response.text,
        "mode":       response.mode,
        "model":      response.model,
        "latency_ms": response.latency_ms,
        "escalated":  response.escalated,
        "retries":    response.retries,
        "routing": {
            "task_type":        response.routing.task_type if response.routing else None,
            "complexity_score": response.routing.complexity_score if response.routing else None,
            "confidence":       response.routing.confidence if response.routing else None,
        } if response.routing else None,
        "error": response.error,
    }


@app.post("/stream")
async def stream(req: CompletionRequest):
    """
    SSE streaming endpoint. Emits tokens as they are generated.
    Format: data: {"token": "...", "done": false}\n\n
    """
    queue: asyncio.Queue[Optional[str]] = asyncio.Queue()

    def on_chunk(text: str):
        queue.put_nowait(text)

    async def run_inference():
        try:
            await agent.ask(
                prompt        = req.prompt,
                session_id    = req.session_id,
                code_context  = req.code_context,
                file_count    = req.file_count,
                error_message = req.error_message,
                on_chunk      = on_chunk,
                use_router    = req.use_router,
            )
        finally:
            queue.put_nowait(None)   # sentinel

    async def event_stream() -> AsyncGenerator[str, None]:
        task = asyncio.create_task(run_inference())
        try:
            while True:
                token = await asyncio.wait_for(queue.get(), timeout=120)
                if token is None:
                    yield f"data: {json.dumps({'token': '', 'done': True})}\n\n"
                    break
                yield f"data: {json.dumps({'token': token, 'done': False})}\n\n"
        except asyncio.TimeoutError:
            yield f"data: {json.dumps({'token': '', 'done': True, 'error': 'timeout'})}\n\n"
        finally:
            task.cancel()

    return StreamingResponse(
        event_stream(),
        media_type = "text/event-stream",
        headers    = {
            "Cache-Control":  "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.post("/session/new")
async def new_session(mode: Optional[str] = None):
    sess = agent.new_session(mode_override=mode)
    return {"session_id": sess.session_id, "mode_override": mode}


# ── Entry Point ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    uvicorn.run(
        "server:app",
        host       = "127.0.0.1",
        port       = 8765,
        log_level  = "info",
        loop       = "asyncio",
        access_log = True,
    )
