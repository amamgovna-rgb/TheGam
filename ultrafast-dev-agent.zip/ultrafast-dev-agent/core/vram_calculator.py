"""
vram_calculator.py
Calculates and validates VRAM requirements per model/quantization.
Prevents overflow before loading any model.
"""

from dataclasses import dataclass
from typing import Optional
import math

# ── Model parameter counts (billions) ──────────────────────────────────────
MODEL_PARAMS = {
    "qwen2.5-coder:7b-q4_K_M":    7.6,
    "qwen2.5-coder:14b-q4_K_M":  14.8,
    "qwen2.5-coder:32b-q4_K_M":  32.5,
    "deepseek-coder:6.7b": 6.7,
    "deepseek-coder:33b":  33.0,
    "codellama:7b-instruct-q4_K_M":         7.0,
    "codellama:13b-instruct-q4_K_M":       13.0,
}

# ── Bits-per-weight for quantization formats ───────────────────────────────
QUANT_BPW = {
    "q4_K_M":  4.5,   # Q4_K_M averages ~4.5 bpw
    "q4_K_S":  4.37,
    "q4_0":    4.0,
    "q5_K_M":  5.68,
    "q6_K":    6.56,
    "q8_0":    8.0,
    "f16":    16.0,
    "f32":    32.0,
}

OVERHEAD_MB   = 400    # CUDA runtime + driver overhead
KV_CACHE_MB_DEFAULT = 512   # default kv cache per context window slice


@dataclass
class VRAMEstimate:
    model_name:        str
    params_billions:   float
    quant_format:      str
    bpw:               float
    model_weights_mb:  float
    kv_cache_mb:       float
    overhead_mb:       float
    total_required_mb: float
    vram_available_mb: float
    fits_on_gpu:       bool
    gpu_layers:        int       # recommended gpu layers
    cpu_overflow_gb:   float     # RAM spill if any
    warning:           Optional[str] = None


def estimate_kv_cache(
    num_ctx:        int,
    num_layers:     int,
    hidden_dim:     int,
    num_heads:      int,
    kv_heads:       int  = 8,    # GQA KV heads (model-specific)
    kv_f16:         bool = True,
    batch_size:     int  = 1,
) -> float:
    """
    KV cache = 2 * layers * ctx * kv_heads * head_dim * dtype_bytes * batch
    2 = K and V tensors
    head_dim = hidden_dim // num_heads
    """
    head_dim   = hidden_dim // num_heads
    dtype_bytes = 2 if kv_f16 else 4
    kv_bytes = 2 * num_layers * num_ctx * kv_heads * head_dim * dtype_bytes * batch_size
    return kv_bytes / (1024 ** 2)   # → MB


# Approximate architecture params for known models
# kv_heads = number of KV heads (GQA). head_dim = hidden // heads.
# KV cache size = 2 * layers * ctx * kv_heads * head_dim * dtype_bytes
MODEL_ARCH = {
    "7b":   {"layers": 32, "hidden": 4096, "heads": 32, "kv_heads": 8},
    "14b":  {"layers": 40, "hidden": 5120, "heads": 40, "kv_heads": 8},
    "32b":  {"layers": 64, "hidden": 5120, "heads": 40, "kv_heads": 8},
    "33b":  {"layers": 60, "hidden": 6656, "heads": 52, "kv_heads": 8},
    "6.7b": {"layers": 32, "hidden": 4096, "heads": 32, "kv_heads": 4},
    "13b":  {"layers": 40, "hidden": 5120, "heads": 40, "kv_heads": 8},
}


def _arch_for_model(model_name: str) -> dict:
    for key in MODEL_ARCH:
        if key in model_name:
            return MODEL_ARCH[key]
    return MODEL_ARCH["7b"]  # safe default


def _quant_from_model(model_name: str) -> str:
    for q in QUANT_BPW:
        if q in model_name:
            return q
    return "q4_K_M"


def calculate_vram(
    model_name:       str,
    num_ctx:          int   = 4096,
    num_batch:        int   = 512,
    kv_f16:           bool  = True,
    vram_available_mb: float = 9840,
) -> VRAMEstimate:
    """
    Full VRAM budget calculation for a given model + context config.
    """
    params_b  = MODEL_PARAMS.get(model_name, 7.0)
    quant_fmt = _quant_from_model(model_name)
    bpw       = QUANT_BPW.get(quant_fmt, 4.5)
    arch      = _arch_for_model(model_name)

    # Model weights in MB
    weights_mb = (params_b * 1e9 * bpw) / (8 * 1024 * 1024)

    # KV cache
    kv_mb = estimate_kv_cache(
        num_ctx    = num_ctx,
        num_layers = arch["layers"],
        hidden_dim = arch["hidden"],
        num_heads  = arch["heads"],
        kv_heads   = arch.get("kv_heads", 8),
        kv_f16     = kv_f16,
        batch_size = 1,
    )

    total_mb     = weights_mb + kv_mb + OVERHEAD_MB
    fits         = total_mb <= vram_available_mb
    gpu_layers   = 99 if fits else _safe_gpu_layers(weights_mb, kv_mb, vram_available_mb, arch)
    cpu_overflow = max(0.0, (total_mb - vram_available_mb) / 1024)

    warning = None
    if not fits:
        warning = (
            f"⚠️  Model requires ~{total_mb:.0f} MB but only "
            f"{vram_available_mb:.0f} MB available. "
            f"Will use {gpu_layers} GPU layers + {cpu_overflow:.1f} GB CPU RAM."
        )

    return VRAMEstimate(
        model_name        = model_name,
        params_billions   = params_b,
        quant_format      = quant_fmt,
        bpw               = bpw,
        model_weights_mb  = round(weights_mb, 1),
        kv_cache_mb       = round(kv_mb, 1),
        overhead_mb       = OVERHEAD_MB,
        total_required_mb = round(total_mb, 1),
        vram_available_mb = vram_available_mb,
        fits_on_gpu       = fits,
        gpu_layers        = gpu_layers,
        cpu_overflow_gb   = round(cpu_overflow, 2),
        warning           = warning,
    )


def _safe_gpu_layers(
    weights_mb:        float,
    kv_mb:             float,
    vram_available_mb: float,
    arch:              dict,
) -> int:
    """
    Calculate how many layers fit in VRAM without overflow.
    """
    budget      = vram_available_mb - OVERHEAD_MB - kv_mb
    mb_per_layer = weights_mb / arch["layers"]
    layers      = math.floor(budget / mb_per_layer) if mb_per_layer > 0 else 0
    return max(0, min(layers, arch["layers"]))


def validate_mode_config(mode_cfg: dict, vram_available_mb: float = 9840) -> dict:
    """
    Validate a mode's model + params against available VRAM.
    Returns enriched config with safe gpu_layers and warnings.
    """
    model_name = mode_cfg["model"]["primary"]
    num_ctx    = mode_cfg["ollama_params"]["num_ctx"]
    num_batch  = mode_cfg["ollama_params"]["num_batch"]
    kv_f16     = mode_cfg["ollama_params"].get("f16_kv", True)

    est = calculate_vram(model_name, num_ctx, num_batch, kv_f16, vram_available_mb)

    result = {
        "mode":            mode_cfg.get("display_name", "unknown"),
        "model":           model_name,
        "vram_estimate":   est,
        "safe_gpu_layers": est.gpu_layers,
        "valid":           True,
        "issues":          [],
        "warnings":        [],
    }

    if est.warning:
        result["warnings"].append(est.warning)

    if not est.fits_on_gpu and est.gpu_layers == 0:
        result["valid"]  = False
        result["issues"].append("❌ Model cannot load at all — insufficient VRAM even for minimal layers.")

    return result


def print_vram_report(estimates: list[VRAMEstimate]) -> None:
    print("\n" + "═" * 72)
    print("  VRAM BUDGET REPORT — RTX 3080 10GB")
    print("═" * 72)
    header = f"{'Model':<42} {'Weights':>8} {'KV':>6} {'Total':>8} {'Fits':>6}"
    print(header)
    print("─" * 72)
    for e in estimates:
        short = e.model_name.replace("instruct-", "")
        fits_str = "✅ YES" if e.fits_on_gpu else f"⚠️  {e.gpu_layers}L"
        print(
            f"{short:<42} {e.model_weights_mb:>7.0f}M "
            f"{e.kv_cache_mb:>5.0f}M "
            f"{e.total_required_mb:>7.0f}M "
            f"{fits_str:>8}"
        )
    print("═" * 72 + "\n")


# ── Self-test ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    VRAM = 9840  # RTX 3080 usable

    test_configs = [
        ("qwen2.5-coder:7b-q4_K_M",   4096,  512, True),
        ("qwen2.5-coder:14b-q4_K_M",  8192,  256, True),
        ("qwen2.5-coder:32b-q4_K_M", 16384,   64, False),
        ("deepseek-coder:6.7b", 4096, 512, True),
        ("deepseek-coder:33b", 8192,  128, False),
    ]

    results = []
    for model, ctx, batch, kv16 in test_configs:
        est = calculate_vram(model, ctx, batch, kv16, VRAM)
        results.append(est)
        if est.warning:
            print(est.warning)

    print_vram_report(results)

    # Validate Ultra-Fast Dev Mode specifically
    import json, pathlib
    cfg_path = pathlib.Path(__file__).parent.parent / "config" / "modes.json"
    if cfg_path.exists():
        cfg = json.loads(cfg_path.read_text())
        for mode_key, mode_val in cfg["modes"].items():
            r = validate_mode_config(mode_val, VRAM)
            status = "✅" if r["valid"] else "❌"
            print(f"{status} {r['mode']}: gpu_layers={r['safe_gpu_layers']}, "
                  f"total={r['vram_estimate'].total_required_mb:.0f}MB")
            for w in r["warnings"]:
                print(f"   {w}")
