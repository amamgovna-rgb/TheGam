"""
agent.py
Main orchestrator for the Ultra-Fast Dev Agent.
Coordinates: mode management, auto-routing, streaming inference, retry logic.
"""

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Callable, Optional

from model_manager import ModelManager, AgentMode, SwitchResult
from auto_router import AutoRouter, RoutingDecision

logger = logging.getLogger("agent")

# ── System Prompts per Mode ────────────────────────────────────────────────

SYSTEM_PROMPTS = {
    "ultra_fast_dev": (
        "You are a fast, expert coding assistant. "
        "Respond with direct code. Minimal explanation unless asked. "
        "No preamble. No markdown prose. Just the solution."
    ),
    "balanced": (
        "You are an expert software engineer. "
        "Provide clear, well-structured code with brief explanations. "
        "Consider edge cases and best practices."
    ),
    "deep_debug": (
        "You are an expert debugger. Analyze the problem systematically. "
        "Explain your reasoning step by step. "
        "Identify root causes and provide fixes with explanations."
    ),
    "full_agent": (
        "You are a senior software architect and autonomous coding agent. "
        "You can reason about entire codebases, design systems, and implement "
        "complex features across multiple files. Be thorough and precise."
    ),
}


@dataclass
class AgentResponse:
    session_id:    str
    mode:          str
    model:         str
    text:          str
    latency_ms:    float
    token_count:   int
    retries:       int
    escalated:     bool
    routing:       Optional[RoutingDecision] = None
    error:         Optional[str]             = None


@dataclass
class AgentSession:
    session_id:     str                    = field(default_factory=lambda: str(uuid.uuid4())[:8])
    mode_override:  Optional[str]          = None   # None = auto
    failure_count:  int                    = 0
    history:        list[dict]             = field(default_factory=list)


class Agent:
    """
    Top-level agent that handles a developer's coding request end-to-end.
    """

    def __init__(self):
        self.model_mgr = ModelManager()
        self.router    = AutoRouter()
        self._sessions: dict[str, AgentSession] = {}

    # ── Session Management ─────────────────────────────────────────────────

    def new_session(self, mode_override: Optional[str] = None) -> AgentSession:
        sess = AgentSession(mode_override=mode_override)
        self._sessions[sess.session_id] = sess
        return sess

    def get_session(self, session_id: str) -> Optional[AgentSession]:
        return self._sessions.get(session_id)

    # ── Core Request Handler ───────────────────────────────────────────────

    async def ask(
        self,
        prompt:        str,
        session_id:    str             = "default",
        code_context:  str             = "",
        file_count:    int             = 1,
        error_message: str             = "",
        on_chunk:      Optional[Callable[[str], None]] = None,
        use_router:    bool            = True,
    ) -> AgentResponse:
        """
        Handle a coding request. Auto-routes, auto-escalates, streams response.
        """
        sess = self._sessions.get(session_id) or AgentSession(session_id=session_id)
        self._sessions[session_id] = sess

        t_start    = time.perf_counter()
        escalated  = False
        routing    = None

        # ── 1. Determine Target Mode ───────────────────────────────────────
        if sess.mode_override:
            target_mode_str = sess.mode_override
        elif use_router and self.router.enabled:
            routing         = self.router.classify(prompt, code_context, file_count, error_message)
            target_mode_str = routing.recommended_mode
            logger.info(
                f"Router → {target_mode_str} "
                f"(score={routing.complexity_score}, conf={routing.confidence})"
            )
        else:
            target_mode_str = self.model_mgr.active_mode.value

        # ── 2. Check for escalation due to failures ────────────────────────
        escalation = self.router.should_escalate(session_id, target_mode_str)
        if escalation:
            logger.warning(
                f"Escalating {target_mode_str} → {escalation} "
                f"(failures={sess.failure_count})"
            )
            target_mode_str = escalation
            escalated       = True

        # ── 3. Switch model if needed ──────────────────────────────────────
        current = self.model_mgr.active_mode.value
        if current != target_mode_str:
            result, msg = await self.model_mgr.switch_mode(AgentMode(target_mode_str))
            if result == SwitchResult.VRAM_OVERFLOW:
                logger.error(f"VRAM overflow switching to {target_mode_str}, staying in {current}")
                target_mode_str = current
            elif result == SwitchResult.MODEL_MISSING:
                logger.warning(f"Model missing for {target_mode_str}, staying in {current}")
                target_mode_str = current

        # ── 4. Build prompt ────────────────────────────────────────────────
        full_prompt = _build_prompt(prompt, code_context, error_message)
        system_p    = SYSTEM_PROMPTS.get(target_mode_str, SYSTEM_PROMPTS["balanced"])

        # ── 5. Inference with retry ────────────────────────────────────────
        mode_cfg    = self.model_mgr.active_config
        max_retries = mode_cfg["agent_behavior"].get("max_retries", 1)
        retries     = 0
        response_text = ""
        err = None

        for attempt in range(max_retries + 1):
            try:
                response_text = await self.model_mgr.stream_completion(
                    prompt   = full_prompt,
                    system   = system_p,
                    on_chunk = on_chunk,
                )
                self.router.record_success(session_id)
                sess.failure_count = 0
                break
            except Exception as e:
                retries += 1
                err = str(e)
                logger.warning(f"Attempt {attempt + 1}/{max_retries + 1} failed: {e}")
                self.router.record_failure(session_id)
                sess.failure_count += 1
                if attempt < max_retries:
                    await asyncio.sleep(0.5 * (attempt + 1))

        latency_ms = (time.perf_counter() - t_start) * 1000

        # ── 6. Post-heavy-task fallback ────────────────────────────────────
        fallback = self.router.post_heavy_task_mode(target_mode_str)
        if fallback and not sess.mode_override:
            asyncio.create_task(
                self.model_mgr.switch_mode(AgentMode(fallback))
            )
            logger.info(f"Post-task: scheduling fallback to {fallback}")

        return AgentResponse(
            session_id  = session_id,
            mode        = target_mode_str,
            model       = self.model_mgr.active_model,
            text        = response_text,
            latency_ms  = round(latency_ms, 1),
            token_count = len(response_text.split()),
            retries     = retries,
            escalated   = escalated,
            routing     = routing,
            error       = err if not response_text else None,
        )

    # ── Manual Mode Switch ─────────────────────────────────────────────────

    async def set_mode(self, mode: str, session_id: Optional[str] = None) -> tuple[bool, str]:
        """Called from UI toggle buttons."""
        try:
            target = AgentMode(mode)
        except ValueError:
            return False, f"Unknown mode: {mode}"

        result, msg = await self.model_mgr.switch_mode(target, force=True)
        ok = result == SwitchResult.SUCCESS

        if ok and session_id and session_id in self._sessions:
            self._sessions[session_id].mode_override = mode

        return ok, msg

    # ── Status ─────────────────────────────────────────────────────────────

    def status(self) -> dict:
        return {
            **self.model_mgr.status(),
            "auto_router": self.router.enabled,
            "sessions":    len(self._sessions),
        }

    async def health_check(self) -> dict:
        """Ping Ollama and return health info."""
        import aiohttp
        url = f"http://127.0.0.1:11434"
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"{url}/api/tags", timeout=aiohttp.ClientTimeout(total=3)) as r:
                    models = await r.json() if r.status == 200 else {}
                    return {
                        "ollama_reachable":  True,
                        "status_code":       r.status,
                        "models_loaded":     len(models.get("models", [])),
                        "active_mode":       self.model_mgr.active_mode.value,
                        "active_model":      self.model_mgr.active_model,
                    }
        except Exception as e:
            return {"ollama_reachable": False, "error": str(e)}


# ── Helpers ────────────────────────────────────────────────────────────────

def _build_prompt(prompt: str, code_context: str, error_message: str) -> str:
    parts = [prompt.strip()]
    if code_context.strip():
        parts.append(f"\n\n```\n{code_context.strip()}\n```")
    if error_message.strip():
        parts.append(f"\n\nError:\n```\n{error_message.strip()}\n```")
    return "\n".join(parts)
