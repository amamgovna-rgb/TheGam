"""
auto_router.py
Intelligent task router that selects the optimal mode based on task complexity.
Falls back to Dev Mode after heavy tasks complete.
"""

import re
import json
import logging
import asyncio
import pathlib
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

logger = logging.getLogger("auto_router")

# ── Task Categories ───────────────────────────────────────────────────────

class TaskType(str, Enum):
    # Dev Mode tasks
    SMALL_FUNCTION   = "small_function"
    REFACTOR         = "refactor"
    QUICK_FIX        = "quick_fix"
    SYNTAX_CHECK     = "syntax_check"
    AUTOCOMPLETE     = "autocomplete"
    RENAME           = "rename"
    DOCSTRING        = "docstring"
    UNIT_TEST_SINGLE = "unit_test_single"

    # Balanced Mode tasks
    MEDIUM_FUNCTION  = "medium_function"
    CLASS_DESIGN     = "class_design"
    MULTI_FUNCTION   = "multi_function"
    BUG_INVESTIGATION = "bug_investigation"
    CODE_REVIEW      = "code_review"
    UNIT_TEST_SUITE  = "unit_test_suite"

    # Deep Debug tasks
    CRASH_ANALYSIS   = "crash_analysis"
    RUNTIME_ERROR    = "runtime_error"
    LOGIC_BUG        = "logic_bug"
    PERFORMANCE      = "performance_profiling"
    MEMORY_LEAK      = "memory_leak"
    DEADLOCK         = "deadlock"

    # Full Agent tasks
    FULL_PROJECT     = "full_project"
    ARCHITECTURE     = "architecture"
    MULTI_FILE_REFACTOR = "multi_file_refactor"
    FEATURE_IMPL     = "feature_implementation"
    API_DESIGN       = "api_design"
    DEPLOYMENT       = "deployment_config"

    UNKNOWN          = "unknown"


TASK_TO_MODE = {
    TaskType.SMALL_FUNCTION:    "ultra_fast_dev",
    TaskType.REFACTOR:          "ultra_fast_dev",
    TaskType.QUICK_FIX:         "ultra_fast_dev",
    TaskType.SYNTAX_CHECK:      "ultra_fast_dev",
    TaskType.AUTOCOMPLETE:      "ultra_fast_dev",
    TaskType.RENAME:            "ultra_fast_dev",
    TaskType.DOCSTRING:         "ultra_fast_dev",
    TaskType.UNIT_TEST_SINGLE:  "ultra_fast_dev",

    TaskType.MEDIUM_FUNCTION:   "balanced",
    TaskType.CLASS_DESIGN:      "balanced",
    TaskType.MULTI_FUNCTION:    "balanced",
    TaskType.BUG_INVESTIGATION: "balanced",
    TaskType.CODE_REVIEW:       "balanced",
    TaskType.UNIT_TEST_SUITE:   "balanced",

    TaskType.CRASH_ANALYSIS:    "deep_debug",
    TaskType.RUNTIME_ERROR:     "deep_debug",
    TaskType.LOGIC_BUG:         "deep_debug",
    TaskType.PERFORMANCE:       "deep_debug",
    TaskType.MEMORY_LEAK:       "deep_debug",
    TaskType.DEADLOCK:          "deep_debug",

    TaskType.FULL_PROJECT:      "full_agent",
    TaskType.ARCHITECTURE:      "full_agent",
    TaskType.MULTI_FILE_REFACTOR: "full_agent",
    TaskType.FEATURE_IMPL:      "full_agent",
    TaskType.API_DESIGN:        "full_agent",
    TaskType.DEPLOYMENT:        "full_agent",
}


@dataclass
class RoutingDecision:
    task_type:       TaskType
    recommended_mode: str
    complexity_score: int           # 0–10
    reasons:          list[str]     = field(default_factory=list)
    confidence:       float         = 0.0   # 0.0–1.0
    escalated:        bool          = False
    fallback_after:   bool          = False  # return to dev mode after?


# ── Keyword Signals ───────────────────────────────────────────────────────

DEV_KEYWORDS = re.compile(
    r"\b(fix|rename|typo|syntax|autocomplete|docstring|comment|format|"
    r"add param|simple function|one.?liner|quick|small|helper|snippet|"
    r"def |lambda|type hint|import|f.?string)\b",
    re.IGNORECASE,
)

BALANCED_KEYWORDS = re.compile(
    r"\b(class|module|interface|implement|write tests|test suite|"
    r"review|refactor class|design|crud|endpoint|controller|service|"
    r"multiple functions?|several|medium|moderate)\b",
    re.IGNORECASE,
)

DEBUG_KEYWORDS = re.compile(
    r"\b(crash(es|ed)?|traceback|exception|error|runtime.?error|typeerror|"
    r"valueerror|attributeerror|keyerror|indexerror|nameerror|"
    r"bug|segfault|deadlock|race.?condition|"
    r"leak|memory.?leak|profile|slow|hang|freeze|stack.?overflow|assertion|"
    r"why does|not working|broken|fails?|wrong output)\b",
    re.IGNORECASE,
)

AGENT_KEYWORDS = re.compile(
    r"\b(entire project|full application|architecture|microservice|"
    r"multi.?file|across files?|codebase|scaffold|generate project|"
    r"api design|database schema|deployment|docker|kubernetes|ci/cd|"
    r"from scratch|complete system|build me)\b",
    re.IGNORECASE,
)

MULTI_FILE_SIGNALS = re.compile(
    r"\b(multiple files?|across files?|all files?|entire codebase|"
    r"project.wide|repo)\b",
    re.IGNORECASE,
)


class AutoRouter:
    """
    Classifies tasks and suggests the optimal mode.
    Escalates or falls back automatically.
    """

    def __init__(self, config_path: Optional[pathlib.Path] = None):
        if config_path is None:
            config_path = pathlib.Path(__file__).parent.parent / "config" / "modes.json"
        cfg = json.loads(config_path.read_text()) if config_path.exists() else {}
        self._auto_enabled = cfg.get("auto_router_enabled", True)
        self._failure_counts: dict[str, int] = {}   # session-level failure tracker

    @property
    def enabled(self) -> bool:
        return self._auto_enabled

    def toggle(self, state: bool) -> None:
        self._auto_enabled = state

    # ── Main Classification ────────────────────────────────────────────────

    def classify(
        self,
        prompt:        str,
        code_context:  str  = "",
        file_count:    int  = 1,
        error_message: str  = "",
    ) -> RoutingDecision:
        """
        Analyze a prompt and return a RoutingDecision.
        """
        text = f"{prompt}\n{code_context}\n{error_message}".lower()

        score = 0
        reasons: list[str] = []

        # ── Feature signals ────────────────────────────────────────────────
        dev_hits     = len(DEV_KEYWORDS.findall(text))
        balanced_hits = len(BALANCED_KEYWORDS.findall(text))
        debug_hits   = len(DEBUG_KEYWORDS.findall(text))
        agent_hits   = len(AGENT_KEYWORDS.findall(text))
        multi_file   = bool(MULTI_FILE_SIGNALS.search(text)) or file_count > 2

        # ── Context size heuristic ─────────────────────────────────────────
        token_est = len(text.split()) * 1.3   # rough token estimate
        if token_est > 3000:
            score  += 4
            reasons.append(f"Large context (~{int(token_est)} tokens)")
        elif token_est > 1500:
            score  += 2
            reasons.append(f"Medium context (~{int(token_est)} tokens)")

        # ── File count ─────────────────────────────────────────────────────
        if multi_file:
            score  += 3
            reasons.append(f"Multi-file scope ({file_count} files)")

        # ── Error / debug signals ──────────────────────────────────────────
        if error_message:
            score  += 3
            reasons.append("Error message present")
        if debug_hits > 0:
            score  += min(debug_hits, 3)
            reasons.append(f"Debug keywords ({debug_hits})")

        # ── Agent signals ──────────────────────────────────────────────────
        if agent_hits > 0:
            score  += min(agent_hits * 2, 5)
            reasons.append(f"Agent-level keywords ({agent_hits})")

        # ── Balanced signals ───────────────────────────────────────────────
        if balanced_hits > 0:
            score  += min(balanced_hits, 2)
            reasons.append(f"Balanced keywords ({balanced_hits})")

        # ── Dev reduces score ──────────────────────────────────────────────
        if dev_hits > 0:
            score  = max(0, score - min(dev_hits, 2))
            reasons.append(f"Dev-mode keywords ({dev_hits})")

        score = min(score, 10)

        # ── Mode selection ─────────────────────────────────────────────────
        if score >= 8 or agent_hits >= 2:
            task_type = TaskType.FULL_PROJECT if multi_file else TaskType.ARCHITECTURE
            mode      = "full_agent"
        elif score >= 5 or debug_hits >= 1:
            task_type = TaskType.CRASH_ANALYSIS if error_message else TaskType.LOGIC_BUG
            mode      = "deep_debug"
        elif score >= 2 or balanced_hits >= 1:
            task_type = TaskType.MULTI_FUNCTION if multi_file else TaskType.MEDIUM_FUNCTION
            mode      = "balanced"
        else:
            task_type = TaskType.SMALL_FUNCTION
            mode      = "ultra_fast_dev"

        confidence = 1.0 - (abs(score - _mode_center(mode)) / 10)

        return RoutingDecision(
            task_type        = task_type,
            recommended_mode = mode,
            complexity_score = score,
            reasons          = reasons,
            confidence       = round(max(0.1, min(1.0, confidence)), 2),
        )

    # ── Failure Escalation ─────────────────────────────────────────────────

    def record_failure(self, session_id: str) -> int:
        """Track consecutive failures for a session."""
        self._failure_counts[session_id] = self._failure_counts.get(session_id, 0) + 1
        return self._failure_counts[session_id]

    def record_success(self, session_id: str) -> None:
        """Reset failure count on success."""
        self._failure_counts[session_id] = 0

    def should_escalate(self, session_id: str, current_mode: str, threshold: int = 2) -> Optional[str]:
        """
        Returns the escalated mode name if threshold exceeded, else None.
        """
        failures = self._failure_counts.get(session_id, 0)
        if failures < threshold:
            return None
        escalation_map = {
            "ultra_fast_dev": "balanced",
            "balanced":       "deep_debug",
            "deep_debug":     "full_agent",
            "full_agent":     None,
        }
        return escalation_map.get(current_mode)

    def post_heavy_task_mode(self, current_mode: str) -> Optional[str]:
        """
        After a full_agent / deep_debug task, suggest returning to dev mode.
        """
        if current_mode in ("full_agent", "deep_debug"):
            return "ultra_fast_dev"
        return None


def _mode_center(mode: str) -> int:
    return {"ultra_fast_dev": 1, "balanced": 4, "deep_debug": 6, "full_agent": 9}.get(mode, 4)


# ── Self-test ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import pathlib
    router = AutoRouter(pathlib.Path(__file__).parent.parent / "config" / "modes.json")

    tests = [
        ("Fix the typo in the function name", "", 1, ""),
        ("Refactor this class to use dependency injection", "class Foo:\n    pass\n" * 20, 1, ""),
        ("The app crashes with AttributeError: NoneType has no attribute 'data'",
         "", 2, "AttributeError: 'NoneType' object has no attribute 'data'"),
        ("Build me a complete REST API microservice with authentication, database, and Docker", "", 5, ""),
        ("Add a docstring to this function", "def foo(x): return x * 2", 1, ""),
    ]

    print("\n🔀 AUTO-ROUTER TEST\n" + "─" * 60)
    for prompt, ctx, files, err in tests:
        d = router.classify(prompt, ctx, files, err)
        print(f"  [{d.recommended_mode:<16}] score={d.complexity_score:02d} "
              f"conf={d.confidence:.2f}  \"{prompt[:50]}\"")
    print("─" * 60)
