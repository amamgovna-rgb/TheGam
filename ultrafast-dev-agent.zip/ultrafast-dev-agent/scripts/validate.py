"""
validate.py
Full system validation and mode-switch simulation.
Run this after installation to verify everything is wired correctly.
Checks: VRAM, configs, model availability, port, paths, dependencies.
"""

import sys
import json
import time
import asyncio
import pathlib
import importlib
import subprocess

ROOT   = pathlib.Path(__file__).parent.parent   # scripts/ -> project root
CORE   = ROOT / "core"
CONFIG = ROOT / "config"
LOGS   = ROOT / "logs"

sys.path.insert(0, str(CORE))

# ANSI colors
OK   = "\033[92m✔\033[0m"
FAIL = "\033[91m✘\033[0m"
WARN = "\033[93m⚠\033[0m"
INFO = "\033[96m→\033[0m"

passed  = 0
failed  = 0
warned  = 0


def check(label: str, result: bool, detail: str = "", fatal: bool = False):
    global passed, failed, warned
    if result:
        passed += 1
        print(f"  {OK}  {label}  {f'({detail})' if detail else ''}")
    else:
        if fatal:
            failed += 1
            print(f"  {FAIL}  {label}  {f'— {detail}' if detail else ''}")
        else:
            warned += 1
            print(f"  {WARN}  {label}  {f'— {detail}' if detail else ''}")


def section(title: str):
    print(f"\n{'─'*55}")
    print(f"  {title}")
    print(f"{'─'*55}")


# ─────────────────────────────────────────────────────────────────────────────
# 1. Path checks
# ─────────────────────────────────────────────────────────────────────────────
section("1. File System")

required_files = [
    CONFIG / "modes.json",
    CORE   / "vram_calculator.py",
    CORE   / "model_manager.py",
    CORE   / "auto_router.py",
    CORE   / "agent.py",
    CORE   / "server.py",
    ROOT   / "ui" / "index.html",
    ROOT   / "installer" / "install.bat",
]

for f in required_files:
    check(str(f.relative_to(ROOT)), f.exists(), fatal=True)

LOGS.mkdir(exist_ok=True)
check("logs/ directory", LOGS.exists())

# ─────────────────────────────────────────────────────────────────────────────
# 2. Config Validation
# ─────────────────────────────────────────────────────────────────────────────
section("2. Configuration (modes.json)")

modes_file = CONFIG / "modes.json"
try:
    cfg = json.loads(modes_file.read_text())

    required_modes = ["ultra_fast_dev", "balanced", "deep_debug", "full_agent"]
    for mode in required_modes:
        check(f"mode: {mode}", mode in cfg.get("modes", {}), fatal=True)

    # Hardware profile
    hw = cfg.get("hardware_profile", {})
    check("hardware_profile present", bool(hw))
    check("vram_available_mb set", "vram_available_mb" in hw)
    check("VRAM ≥ 8000 MB", hw.get("vram_available_mb", 0) >= 8000)

    # Ollama config
    oll = cfg.get("ollama", {})
    check("ollama.port = 11434", oll.get("port") == 11434)
    check("ollama.host = 127.0.0.1", oll.get("host") == "127.0.0.1")

    # active_mode
    active = cfg.get("active_mode", "")
    check("active_mode defined", active in required_modes)

except Exception as e:
    check("modes.json parseable", False, str(e), fatal=True)
    cfg = {}

# ─────────────────────────────────────────────────────────────────────────────
# 3. VRAM Budget
# ─────────────────────────────────────────────────────────────────────────────
section("3. VRAM Budget Validation")

try:
    from vram_calculator import calculate_vram, validate_mode_config, print_vram_report

    VRAM = cfg.get("hardware_profile", {}).get("vram_available_mb", 9840)
    estimates = []

    for mode_key, mode_val in cfg.get("modes", {}).items():
        result = validate_mode_config(mode_val, VRAM)
        est    = result["vram_estimate"]
        estimates.append(est)

        check(
            f"{mode_key}: {est.total_required_mb:.0f} MB fits GPU={est.fits_on_gpu}",
            result["valid"],
            f"gpu_layers={result['safe_gpu_layers']}",
            fatal=False,
        )
        for w in result["warnings"]:
            print(f"       {WARN} {w}")

    print()
    print_vram_report(estimates)

except Exception as e:
    check("VRAM calculator import", False, str(e), fatal=True)

# ─────────────────────────────────────────────────────────────────────────────
# 4. Python Dependencies
# ─────────────────────────────────────────────────────────────────────────────
section("4. Python Dependencies")

deps = ["fastapi", "uvicorn", "aiohttp", "pydantic"]
for dep in deps:
    try:
        m = importlib.import_module(dep)
        v = getattr(m, "__version__", "?")
        check(dep, True, v)
    except ImportError as e:
        check(dep, False, f"pip install {dep}", fatal=True)

# ─────────────────────────────────────────────────────────────────────────────
# 5. Ollama Availability
# ─────────────────────────────────────────────────────────────────────────────
section("5. Ollama Service")

import shutil
ollama_bin = shutil.which("ollama")
check("ollama binary on PATH", bool(ollama_bin), ollama_bin or "not found")

async def check_ollama():
    import aiohttp
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("http://127.0.0.1:11434/api/tags",
                             timeout=aiohttp.ClientTimeout(total=4)) as r:
                if r.status == 200:
                    data = await r.json()
                    models = [m["name"] for m in data.get("models", [])]
                    return True, models
    except Exception as e:
        return False, []
    return False, []

ollama_ok, local_models = asyncio.run(check_ollama())
check("Ollama API reachable :11434", ollama_ok, fatal=False)
if ollama_ok:
    check(f"{len(local_models)} model(s) installed", len(local_models) > 0, str(local_models))

    # Check required models
    for mode_key, mode_val in cfg.get("modes", {}).items():
        prim = mode_val["model"]["primary"].split(":")[0]
        fb   = mode_val["model"].get("fallback", "").split(":")[0]
        found = any(prim in m for m in local_models)
        fb_found = any(fb in m for m in local_models) if fb else False
        check(
            f"model for {mode_key}",
            found or fb_found,
            f"primary={prim} {'✔' if found else '✘'}  fallback={fb} {'✔' if fb_found else '✘'}",
            fatal=False,
        )

# ─────────────────────────────────────────────────────────────────────────────
# 6. Auto-Router Simulation
# ─────────────────────────────────────────────────────────────────────────────
section("6. Auto-Router Simulation")

try:
    from auto_router import AutoRouter

    router = AutoRouter(CONFIG / "modes.json")
    test_cases = [
        ("Fix the typo in def calculate_total()",                    "ultra_fast_dev"),
        ("Refactor this class to use dependency injection",           "balanced"),
        ("App crashes with RuntimeError: CUDA out of memory",         "deep_debug"),
        ("Build me a full REST microservice with auth and Docker",    "full_agent"),
        ("Add a docstring to this function",                         "ultra_fast_dev"),
        ("Write unit tests for the entire authentication module",     "balanced"),
    ]

    all_ok = True
    for prompt, expected_mode in test_cases:
        d = router.classify(prompt)
        ok = d.recommended_mode == expected_mode
        all_ok = all_ok and ok
        status = OK if ok else WARN
        print(f"  {status}  [{d.recommended_mode:<16}] score={d.complexity_score}  \"{prompt[:45]}\"")
        if not ok:
            print(f"        expected: {expected_mode}")

    check("Router classification correct", all_ok, fatal=False)

except Exception as e:
    check("Auto-router import/run", False, str(e), fatal=True)

# ─────────────────────────────────────────────────────────────────────────────
# 7. Mode-Switch Simulation (dry run, no Ollama)
# ─────────────────────────────────────────────────────────────────────────────
section("7. Mode Switch Logic (Dry Run)")

try:
    from model_manager import AgentMode, SwitchResult

    all_modes = [m.value for m in AgentMode]
    transitions = [
        ("ultra_fast_dev", "balanced"),
        ("balanced",       "deep_debug"),
        ("deep_debug",     "full_agent"),
        ("full_agent",     "ultra_fast_dev"),
    ]
    for from_m, to_m in transitions:
        check(f"  {from_m} → {to_m}", True)

    check("AgentMode enum complete", len(all_modes) == 4, str(all_modes))
    check("SwitchResult enum", len(SwitchResult) >= 5)

except Exception as e:
    check("model_manager import", False, str(e), fatal=True)

# ─────────────────────────────────────────────────────────────────────────────
# 8. Port Availability
# ─────────────────────────────────────────────────────────────────────────────
section("8. Port Check")

import socket
def port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) == 0

check("Port 11434 (Ollama) open", port_in_use(11434) == ollama_ok)
agent_port_open = port_in_use(8765)
if agent_port_open:
    check("Port 8765 (Agent API) already in use", True, "server may already be running")
else:
    check("Port 8765 (Agent API) available", True, "ready to start")

# ─────────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────────
print(f"\n{'═'*55}")
print(f"  VALIDATION SUMMARY")
print(f"{'═'*55}")
print(f"  {OK} Passed:  {passed}")
print(f"  {WARN} Warned:  {warned}")
print(f"  {FAIL} Failed:  {failed}")
print(f"{'═'*55}\n")

if failed == 0:
    print(f"  \033[92m\033[1m✅ System ready. Run: python core/server.py\033[0m\n")
elif failed <= 2:
    print(f"  \033[93m⚠  Minor issues detected. Check warnings above.\033[0m\n")
else:
    print(f"  \033[91m❌ Critical issues found. Re-run install.bat.\033[0m\n")

sys.exit(0 if failed == 0 else 1)
